import pathlib,re,json,collections,gzip
root=pathlib.Path.cwd();o=root/'bench/results/p11c-sycl-fa-tile-fp16-fix-20261011'
ansi=re.compile(r'\x1b\[[0-9;]*m')
def clean(s):return ansi.sub('',s)
def rows(text):
 chunks=re.split(r'(?=\[FA-DISP\])',clean(text));result=[]
 for chunk in chunks:
  d=re.search(r'\[FA-DISP\] #\d+ (\w+) D=(\d+)',chunk)
  pb=re.search(r'\[FA-PB\] parallel_blocks=(\d+) ntiles_total=(\d+) nbatch_fa=(\d+) ne11=(\d+)',chunk)
  case=re.search(r'FLASH_ATTN_EXT\((hsk=.*?)\): (OK|FAIL|UNSUPPORTED)',chunk)
  nmse=re.search(r'\[FLASH_ATTN_EXT\] ERR = ([\d.]+)',chunk)
  if not(d and pb and case and nmse):continue
  shape=case[1];kv=int(re.search(r'kv=(\d+)',shape)[1]);nb=int(re.search(r'nb=(\d+)',shape)[1]);p=int(pb[1]);route=d[1]
  assert kv==int(pb[4]);assert kv%(p*(16 if route=='VEC' else 1))==0
  result.append((int(d[2]),kv,nb,route,p,int(pb[2]),int(pb[3]),kv//(p*(16 if route=='VEC' else 1)),case[2],nmse[1]))
 return result
parts=[]
parts.append(r'''p11c: two independent SYCL TILE FP16 candidate fixes, 2026-10-11

Scope
-----
Branch p11c-sycl-fa-tile-fp16-fix-candidates, based on main a78c40c.
llama.cpp pin 79e2e74eb11022c1ba2e438df7f0ca2d4c10f8b6.
base = pin + numbered patches 0001-0005 + updated test-only CPU patch.
F = base + F-SYCL-FA-tile-flush-FP16-VKQ-to-FP32-per-KV-tile.patch.
S = base + S-SYCL-FA-tile-cap-keys-per-block.patch.
All three also receive the identical archived scratch diagnostic diff.
Device: Intel Xeon E3-1505M v6 @ 3.00GHz, Intel OpenCL 3.0, 8 compute
units, max work-group 8192, driver 2026.21.7.0.24_160000.
Intel OpenCL CPU device only; these are same-source CPU numerics, not A770
numerics. Static target acm-g10 only. Timing: not run.
Wall times include build, configure, CPU JIT and tests or static compilation;
they are not performance measurements. No candidate is selected.
No tolerance changes, existing test changes, installs, network, commits,
pushes, main-checkout writes or prohibited device instructions were used.

Implementation and sizing
-------------------------
F ported from the P100 project, patch 0004. Only fattn-tile.hpp changes.
A float2 VKQ_f32 sits next to half2 VKQ, with equal element counts. Each KV
iteration rescales VKQ_f32 in FP32, accumulates its tile in half2, adds that
tile into VKQ_f32 and zeros VKQ. The np>1 combine reuses KV_tmp as floats;
a byte-size static_assert proves nwarps*DVp floats fit. Copies use float2
and 8 bytes per element. Sink rescale and final output also use VKQ_f32.
The entire source projection with SYCL_FAST_FP16 absent is byte-identical
(assertion in preparation script); actual git diff hunks are archived in
patch-validation.log.gz. This is a source audit, not a non-fast runtime test.

S changes only host launch plumbing: defaulted max_keys=0, set to 1024 by
all six TILE launches. The measured p11b bound is cited beside the define.
In the non-stream-k path, before the unchanged efficiency search, use
min(ntiles_KQ, max(previous_bound, ceil(ntiles_KQ*nbatch_fa/max_keys))).
The product is calculated in int64_t. VEC and all other callers omit the
parameter, retaining 0 and the original split. Stream-k is unchanged.
After the search, existing dst_tmp.alloc(parallel_blocks*ggml_nelements(KQV))
and dst_tmp_meta.alloc(parallel_blocks*ggml_nrows(KQV)) use the final block
count. blocks_num.y and the combine's parallel_blocks argument use the same
count; its local storage is parallel_blocks*sizeof(float2). Thus all partial
outputs, metadata and combine storage grow with S's larger split. Phantom
heads from 0001 do not write output and combine uses actual Q dimensions.

Reproduction
------------
Start every shell command with:
  export PATH=/home/p51/Github/A770/.venv/bin:$PATH;
  export A770_TOOLS=/home/p51/Github/A770/tools
Local scratch setup (no network):
  git clone --no-hardlinks --no-checkout third_party/llama.cpp third_party/p11c/<variant>
  git -C third_party/p11c/<variant> checkout --detach 79e2e74
  for patch in "$PWD"/third_party/patches/000[1-5]-*.patch; do
    git -C third_party/p11c/<variant> apply "$patch"
  done
  git -C third_party/p11c/<variant> apply "$PWD/third_party/patches/test-only/0001-sycl-allow-cpu-device-for-tests.patch"
Paths passed to git apply are absolute in the archived preparation script.
For F/S apply the respective candidate, then decompress and apply the archived <variant>-scratch-diagnostics.diff.gz.
prepare.py.gz records the exact candidate derivation and checks; runs.py.gz
records the exact serial run orchestration. commands.json.gz lists commands,
geometry, LLAMA, actual exit codes and wall times for every completed run.

Numerical environment:
  export SYCL_CACHE_PERSISTENT=1 SYCL_CACHE_DIR=/tmp/p11c-sycl-cache
  export GGML_SYCL_MKL_FA_DEBUG=1
  unset SYCL_PROGRAM_COMPILE_OPTIONS SYCL_PROGRAM_BUILD_OPTIONS SYCL_CPU_F16
  export LLAMA=$PWD/third_party/p11c/<base|F|S>
Geometries:
  g-cpu: unset GGML_SYCL_TEST_NSM GGML_SYCL_TEST_MAX_WG_PER_CU
  g-a770: export GGML_SYCL_TEST_NSM=32 GGML_SYCL_TEST_MAX_WG_PER_CU=2
  g-min: export GGML_SYCL_TEST_NSM=32 GGML_SYCL_TEST_MAX_WG_PER_CU=1
Run each base/F/S at g-a770 and g-min:
  bin/sycl-cpu-tbo.sh -o FLASH_ATTN_EXT -p 'v_bias=2'
Run each F/S at g-cpu and g-a770:
  bin/sycl-cpu-tbo.sh -o FLASH_ATTN_EXT -p "$P"
  bin/sycl-cpu-tbo.sh -o FLASH_ATTN_EXT -p 'nr23=\[[3567],1\]'
P is copied verbatim from the p6a README into filters.txt.gz (included below).
On the mandated 0001-0005 stack this selects 97 cases: the original 85 plus
12 added by 0002 (GQA=6, two dimensions, five selected non-sink F16 batches
and one selected Q8 batch per dimension). No cases or filters were changed.
The complete historical 85-case multiset, including its duplicate, is checked
against every new P log (historical-P-cases.log.gz, sourced from p11b A g-cpu).
All tests use F16 ON, Release optimized spir64 JIT, per-kernel images,
oneDNN and Level Zero OFF, target test-backend-ops, -j 8. The harness validates
SYCL0 is Intel OpenCL CPU in an empty preflight, then runs the selected tests.
Preflight 0/0 summaries and the skipped separate CPU backend are not successes
in the reported case counts. Input tensors are randomly initialized across
runs; these are not paired experiments on identical inputs.
219 prior p11b CPU JIT cache files seeded without overwrite, each hash verified;
268 additional p6b CPU JIT cache files were later seeded the same way.
cache-seed.log.gz and cache-seed-p6b.log.gz give provenance. Cache keys
select matching source/options; unmatched entries do not bypass compilation.
''')
# device/geometry evidence
for v in ('base','F','S'):
 for g in ('g-a770','g-min'):
  name=f'{v}-{g}-bias';t=(o/(name+'.log')).read_text(errors='replace');r=rows(t);assert len(r)==16,(name,len(r))
  parts.append('\n'+name+'\nD    kv     nb   route p    T    tile keys/acc result NMSE\n')
  for D,kv,nb,route,p,T,tile,keys,res,nmse in r:
   parts.append(f'{D:<4} {kv:<6} {nb:<4} {route:<5} {p:<4} {T:<4} {tile:<4} {keys:<8} {"PASS" if res=="OK" else res:<6} {nmse}\n')
  parts.append('\n'.join(l for l in clean(t).splitlines() if 'tests passed' in l or 'backends passed' in l)+'\n'+(o/(name+'.time')).read_text())
  if v=='base' and g=='g-a770':assert sum(x[-2]=='OK' for x in r)==12
parts.append('''
Biased-V tables: D=128/256, KV=16384/32768, nb=1/4/16/512, GQA=4,
no mask, F16 K/V, KV views, V+2 on channels 0..7. Unchanged NMSE tolerance
0.000500000. Route/p/T/tile are measured diagnostic prints. keys/acc is
source-derived: TILE kv/p; VEC kv/(16*p), since VEC has 16 warp/lane partial
sums per block. All selected shapes divide evenly. F's keys/acc column means
keys processed by each block's carried accumulator; its half2 accumulator
is reset every tile (64 keys here). NMSE prints have nine decimal places;
printed zero does not imply mathematical equality.

Existing coverage result lines
------------------------------
Patch 0002 adds 112 cases (2 dimensions x 4 GQA ratios x (6 batches x
2 sink settings + 2 quantized batches)); the requested filter also selects
five pre-existing matching cases, for 117 total. All 112 patch-0002 case
strings are checked with multiplicity against every P6 log. Source-derived
case strings and the five additional cases are archived in
patch-0002-cases.log.gz and P6-coverage-audit.log.gz. Counts below are measured
from the runner.
''')
for v in ('F','S'):
 for g in ('g-cpu','g-a770'):
  for subset in ('P','P6'):
   name=f'{v}-{g}-{subset}';t=clean((o/(name+'.log')).read_text(errors='replace'))
   summaries=[l.strip() for l in t.splitlines() if 'tests passed' in l or 'backends passed' in l]
   cases=re.findall(r'FLASH_ATTN_EXT\((hsk=.*?)\): (OK|FAIL|UNSUPPORTED)',t)
   if subset=='P':
    assert len(cases)==97,(name,len(cases))
    historical=gzip.open(o/'historical-P-cases.log.gz','rt').read().splitlines()[1:]
    old=collections.Counter(historical);current=collections.Counter(shape for shape,res in cases)
    assert not (old-current),(name,'missing historical cases',old-current)
    assert sum((current-old).values())==12,(name,'unexpected additions')
   if subset=='P6':
    assert len(cases)==117,(name,len(cases))
    added=collections.Counter(gzip.open(o/'patch-0002-cases.log.gz','rt').read().splitlines()[1:])
    current=collections.Counter(shape for shape,res in cases)
    assert not (added-current),(name,'missing 0002 cases',added-current)
    assert sum((current-added).values())==5
   counts=collections.Counter(x[1] for x in cases)
   parts.append(f'{name}: '+', '.join(summaries[-2:])+f'; counted {dict(counts)}\n'+(o/(name+'.time')).read_text())
   failures=[shape for shape,res in cases if res!='OK']
   if failures:parts.append('Findings:\n'+'\n'.join(failures)+'\n')
parts.append('''
Static comparison (new base report, no prior-report reuse)
----------------------------------------------------------
  LLAMA=$PWD/third_party/p11c/base bin/llama-sycl-fa-static.sh bench/results/p11c-sycl-fa-tile-fp16-fix-20261011/static-base
  LLAMA=$PWD/third_party/p11c/F bin/llama-sycl-fa-static.sh bench/results/p11c-sycl-fa-tile-fp16-fix-20261011/static-F
Both use A770_TOOLS=/home/p51/Github/A770/tools; IGC acm-g10, AOT -O2,
default GRF mode. No CPU override/device acceptance gate for static reports.
The script reports TILE dkq64/128/256 plus two VEC translation units.
TU xe-report rc=1 flags resource violations such as upstream spills; the
script exits 0 when compilation and row extraction succeed (rc>=2 fails).
Below only actual lauch_kernel TILE device bodies, excluding host launch,
copy and fixup wrappers. Every emitted ncols1/ncols2/logit-softcap instance
is compared; all retain the requested subgroup 32.
D64 softcap=true is an unused return-only variant (zero SLM/spill); active
instance summaries exclude those 17 empty bodies. All TILE body rows in
both reports have zero DPAS and FP64 instruction counts.
D   cols1 cols2 softcap GRF base->F SIMD base->F spill bytes base->F delta
''')
def static(v,D):
 t=(o/f'static-{v}'/f'fattn-tile-instance-dkq{D}-dv{D}.txt').read_text()
 result={}
 for l in t.splitlines():
  if not l.lstrip().startswith('lauch_kernel<'):continue
  key=re.search(r'flash_attn_tile<(\d+), (\d+), (\d+), (\d+), (false|true), (\d+)>',l)
  nums=re.search(r'\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*(?:SPILL.*)?$',l)
  assert key and nums,l
  k=tuple(key.groups());assert k not in result
  result[k]=tuple(map(int,nums.groups()))
 return result
changes=[]
static_costs={}
for D in (64,128,256):
 a=static('base',D);f=static('F',D);assert a.keys()==f.keys();assert a
 active=[k for k in a if a[k][5]>0]
 deltas=[f[k][3]-a[k][3] for k in active]
 static_costs[D]=(len(active),min(deltas),max(deltas),max(a[k][3] for k in active),max(f[k][3] for k in active))
 for k in sorted(a,key=lambda k:(int(k[2]),int(k[3]),k[4])):
  x,y=a[k],f[k];parts.append(f'{D:<3} {k[2]:<5} {k[3]:<5} {k[4]:<7} {x[1]}->{y[1]:<3}    {x[0]}->{y[0]:<2}        {x[3]}->{y[3]:<6} {y[3]-x[3]:+d}\n')
  if x[:2]!=y[:2]:changes.append((k,x[:2],y[:2]))
parts.append('SIMD/GRF changes: '+(str(changes) if changes else 'none')+'\n')
for v in ('base','F'):
 parts.append('\n'+(o/f'static-{v}'/'summary.txt').read_text()+(o/f'static-{v}.time').read_text())
parts.append('''
Required checks and applicability
---------------------------------
Fresh independent pin clone + 0001-0005, without CPU patch/diagnostics:
  git apply --check <F candidate>: exit 0
  git apply --check <S candidate>: exit 0
Source audit, fresh-stack patch checks, actual F git diff hunks and whitespace
checks are archived in patch-validation.log.gz; preparation asserts non-fast
projection identity. Scratch-only diagnostic diffs are archived for all clones.
''')
parts.append('bin/check-forbidden.sh: '+(o/'forbidden.log').read_text())
parts.append('shellcheck -x bin/*.sh: '+((o/'shellcheck.log').read_text() or 'exit 0, no diagnostics\n'))
ct=(o/'repo-checks.log').read_text();parts.append('Repo checks (host compiler; A770_TOOLS unset and local tools/ absent;\nnine xe-report fixture tests skipped):\n  cmake -S . -B /tmp/p11c-a770-repo-build -G Ninja\n  cmake --build /tmp/p11c-a770-repo-build -j 2\n  ctest --test-dir /tmp/p11c-a770-repo-build --output-on-failure\n')
parts.append('\n'.join(l for l in ct.splitlines() if 'tests passed' in l or 'Total Test time' in l)+'\n'+(o/'repo-checks.time').read_text())
parts.append('''
Not verified
------------
A770 numerical correctness, driver work-group limits, runtime memory behavior
or speed; real-model V statistics; full test-backend-ops coverage; oneDNN;
non-FAST_FP16 runtime; skipped repo static tests. Biased V remains a stress
case. No candidate enters the numbered series and neither is chosen here.

Exact filters
-------------
'''+(o/'filters.txt').read_text())
summary=['Measured summary\n----------------\nvariant  g-a770 biased pass / max TILE NMSE   g-min biased pass / max TILE NMSE\n']
for v in ('base','F','S'):
 fields=[]
 for g in ('g-a770','g-min'):
  r=rows((o/f'{v}-{g}-bias.log').read_text());fields.append(f'{sum(x[-2]=="OK" for x in r)}/16 / {max(float(x[-1]) for x in r if x[3]=="TILE"):.9f}')
 summary.append(f'{v:<8} {fields[0]:<35} {fields[1]}\n')
for v in ('F','S'):
 for g in ('g-cpu','g-a770'):
  fields=[]
  for subset in ('P','P6'):
   t=clean((o/f'{v}-{g}-{subset}.log').read_text())
   results=re.findall(r'FLASH_ATTN_EXT\((hsk=.*?)\): (OK|FAIL|UNSUPPORTED)',t)
   fields.append(f'{subset} {sum(res=="OK" for shape,res in results)}/{len(results)}')
  summary.append(f'{v} {g}: '+', '.join(fields)+'\n')
summary.append('The 97 P cases include all original 85 plus 12 additions; P6 includes all\n112 patch-0002 cases plus five pre-existing matches.\nStatic active TILE bodies (spill delta min..max in bytes, maximum spill base->F):\n')
for D,(n,lo,hi,mb,mf) in static_costs.items():summary.append(f'  D={D}: {n} active instances; delta {lo:+d}..{hi:+d}; max {mb}->{mf}\n')
summary.append('SIMD/GRF changes: '+(str(changes) if changes else 'none')+'\nNo A770 runtime or performance verification; no candidate chosen.\n\n')
parts[0]=parts[0].replace('Implementation and sizing\n', ''.join(summary)+'Implementation and sizing\n',1)
(o/'README.txt').write_text(''.join(parts))
with (o/'README.txt').open('a') as artifact_file:
 artifact_file.write('\nArtifacts\n---------\n*.log.gz: complete stdout/stderr and audit records.\ncommands.json.gz: exact run argv, geometry, LLAMA, exit code and wall time.\nwall-times.log.gz: original timing records for all runs and repo checks.\nfilters.txt.gz: exact quoted filters (also included above).\nprepare.py.gz, runs.py.gz, report.py.gz: preparation, orchestration and report extraction.\nF/S-candidate.diff.gz: candidate source differences before scratch diagnostics.\nbase/F/S-scratch-diagnostics.diff.gz: identical print-only scratch changes.\npatch-validation.log.gz: fresh-stack apply checks and actual F git diff hunks.\nsource-audit.log.gz and test-source-audit.log.gz: source identity and provenance.\nP/P6-coverage-audit.log.gz: membership of historical and patch-0002 case sets.\nsplit-audit.log.gz: F/base split identity, unchanged S VEC and measured S TILE cap.\nstatic-base/ and static-F/: raw per-TU IGC reports, configure output and summaries.\n')
print('README written')
