import pathlib,re,subprocess,difflib,gzip
root=pathlib.Path.cwd(); out=root/'bench/results/p11c-sycl-fa-tile-fp16-fix-20261011'
rel='ggml/src/ggml-sycl/fattn-tile.hpp'
b=(root/'third_party/p11c/base'/rel).read_text(); f=b
# Preserve the original signature and calls verbatim in the non-fast branches.
sig='                                                 T_acc * const     VKQ,\n'
f=f.replace(sig,sig+'#ifdef SYCL_FAST_FP16\n                                                 sycl::float2 * const VKQ_f32,\n#endif // SYCL_FAST_FP16\n',1)
for jc in ('jc','jc0'):
 old='            const sycl::half2 KQ_max_scale_h2 = sycl::half2(KQ_max_scale, KQ_max_scale);\n#pragma unroll\n            for (int i0 = 0; i0 < DVp/2; i0 += warp_size) {\n'
 if jc=='jc':
  old+=f'                VKQ[{jc}*((DVp/2)/warp_size) + i0/warp_size].x() *= KQ_max_scale_h2.x();\n                VKQ[{jc}*((DVp/2)/warp_size) + i0/warp_size].y() *= KQ_max_scale_h2.y();\n            }}'
 else:
  old+=f'                VKQ[{jc}*((DVp/2)/warp_size) + i0/warp_size] *= KQ_max_scale_h2;\n            }}'
 new=f'#pragma unroll\n            for (int i0 = 0; i0 < DVp/2; i0 += warp_size) {{\n                VKQ_f32[{jc}*((DVp/2)/warp_size) + i0/warp_size].x() *= KQ_max_scale;\n                VKQ_f32[{jc}*((DVp/2)/warp_size) + i0/warp_size].y() *= KQ_max_scale;\n            }}'
 assert old in f,jc; f=f.replace(old,new,1)
needle='        item_ct1.barrier(sycl::access::fence_space::local_space);\n    }\n}\n\ntemplate <int DKQ, int DV, int ncols1'
flush='''        item_ct1.barrier(sycl::access::fence_space::local_space);
    }
#ifdef SYCL_FAST_FP16
#pragma unroll
    for (int i = 0; i < cpw * ((DVp/2)/warp_size); ++i) {
        const sycl::float2 tile = VKQ[i].template convert<float, sycl::rounding_mode::automatic>();
        VKQ_f32[i] += tile;
        VKQ[i] = make_half2(0.0f, 0.0f);
    }
#endif // SYCL_FAST_FP16
}

template <int DKQ, int DV, int ncols1'''
assert needle in f; f=f.replace(needle,flush,1)
needle='    __dpct_align__(16) sycl::half2 VKQ[cpw * ((DVp / 2) / warp_size)] = {\n        { 0.0f, 0.0f }\n    };'
f=f.replace(needle,needle+'\n    __dpct_align__(16) sycl::float2 VKQ_f32[cpw * ((DVp / 2) / warp_size)] = {{0.0f, 0.0f}};',1)
# Keep exact original argument lines when FAST_FP16 is absent.
line='                                            stride_V2, stride_mask, KQ_max, KQ_sum, VKQ, k_VKQ_0, k_VKQ_max, col_Q_0,\n'
assert f.count(line)==3
f=f.replace(line,'#ifdef SYCL_FAST_FP16\n'+line.replace('VKQ, k_','VKQ, VKQ_f32, k_')+'#else\n'+line+'#endif // SYCL_FAST_FP16\n')
f=f.replace('        sycl::half2 * VKQ_combine = (sycl::half2 *) KV_tmp;','        static_assert(lsm_size2 * sizeof(sycl::half2) >= nwarps * DVp * sizeof(float),\n                      "KV_tmp too small for FP32 combine");\n        float * VKQ_combine = (float *) KV_tmp;',1)
old='''            constexpr int cpy_ne_D = cpy_ne < (DVp/2)/warp_size ? cpy_ne : (DVp/2)/warp_size;
#pragma unroll
            for (int i0 = 0; i0 < DVp/2; i0 += warp_size*cpy_ne_D) {
                ggml_sycl_memcpy_1<cpy_ne_D * 4>(
                    &VKQ_combine[item_ct1.get_local_id(1) * (DVp / 2) + i0 + item_ct1.get_local_id(2) * cpy_ne_D],
                    &VKQ[i0 / warp_size]);
            }'''
new='''            constexpr int cpy_ne_D = cpy_ne/2 < (DVp/2)/warp_size ? cpy_ne/2 : (DVp/2)/warp_size;
#pragma unroll
            for (int i0 = 0; i0 < DVp/2; i0 += warp_size*cpy_ne_D) {
                ggml_sycl_memcpy_1<cpy_ne_D * 8>(
                    &VKQ_combine[item_ct1.get_local_id(1) * DVp + 2*i0 + item_ct1.get_local_id(2) * (2*cpy_ne_D)],
                    &VKQ_f32[i0 / warp_size]);
            }'''
assert old in f;f=f.replace(old,new,1)
old='''            constexpr int cpy_ne_D = cpy_ne < (DVp/2)/warp_size ? cpy_ne : (DVp/2)/warp_size;
#pragma unroll
            for (int i0 = 0; i0 < DVp/2; i0 += warp_size*cpy_ne_D) {
                __dpct_align__(16) sycl::half2 tmp[cpy_ne_D];
                ggml_sycl_memcpy_1<cpy_ne_D * 4>(tmp, &VKQ_combine[(item_ct1.get_local_id(1) + ip) * (DVp / 2) + i0 +
                                                                   item_ct1.get_local_id(2) * cpy_ne_D]);
#pragma unroll
                for (int i1 = 0; i1 < cpy_ne_D; ++i1) {
                    VKQ[i0/warp_size + i1] += tmp[i1];
                }
            }'''
new=old.replace('cpy_ne <','cpy_ne/2 <').replace('? cpy_ne :','? cpy_ne/2 :').replace('sycl::half2 tmp','sycl::float2 tmp').replace('cpy_ne_D * 4','cpy_ne_D * 8').replace('* (DVp / 2) + i0','* DVp + 2*i0').replace('* cpy_ne_D]);','* (2*cpy_ne_D)]);').replace('VKQ[i0/','VKQ_f32[i0/')
assert old in f;f=f.replace(old,new,1)
old='''                tmp[i1] = VKQ[jc0 * ((DVp / 2) / warp_size) + i0 / warp_size + i1]
                              .template convert<float, sycl::rounding_mode::automatic>();'''
assert old in f; f=f.replace(old,'                tmp[i1] = VKQ_f32[jc0 * ((DVp / 2) / warp_size) + i0 / warp_size + i1];',1)
(root/'third_party/p11c/F'/rel).write_text(f)
# Strip only FAST_FP16 directives to prove byte identity of the entire non-fast source.
def nonfast(src):
 lines=src.splitlines(keepends=True);result=[]; stack=[];active=True
 for l in lines:
  if l.startswith('#ifdef SYCL_FAST_FP16'):
   stack.append((active,False));active=False
  elif re.match(r'#(if|ifdef|ifndef)\b',l):
   stack.append((active,None));
   if active:result.append(l)
  elif l.startswith('#else') and stack and stack[-1][1] is not None:
   active=stack[-1][0]
  elif l.startswith('#endif') and stack:
   parent,kind=stack.pop()
   if kind is None and active:result.append(l)
   active=parent
  elif active:result.append(l)
 return ''.join(result)
assert nonfast(b)==nonfast(f),'Non-fast source changed'
print('Entire non-FAST_FP16 projection byte-identical')
common='ggml/src/ggml-sycl/fattn-common.hpp'; c=(root/'third_party/p11c/base'/common).read_text()
s=c.replace('const bool need_f16_V, const bool stream_k) {','const bool need_f16_V, const bool stream_k, const int max_keys = 0) {',1)
needle='        parallel_blocks = std::min(parallel_blocks, ntiles_KQ);'
s=s.replace(needle,needle+'''
        if (max_keys > 0) {
            const int min_blocks = (int64_t(ntiles_KQ) * nbatch_fa + max_keys - 1) / max_keys;
            parallel_blocks = std::min(ntiles_KQ, std::max(parallel_blocks, min_blocks));
        }''',1)
(root/'third_party/p11c/S'/common).write_text(s)
s=b.replace('#define GGML_SYCL_FATTN_TILE_PAD_MAX_COLS 32','#define GGML_SYCL_FATTN_TILE_PAD_MAX_COLS 32\n\n// Measured p11b bound: 1024 keys per TILE accumulator (NMSE about 8e-6).\n#define GGML_SYCL_FATTN_TILE_MAX_KEYS_PER_BLOCK 1024',1)
assert s.count('nbatch_fa, true, true, false);')==6
s=s.replace('nbatch_fa, true, true, false);','nbatch_fa, true, true, false, GGML_SYCL_FATTN_TILE_MAX_KEYS_PER_BLOCK);')
(root/'third_party/p11c/S'/rel).write_text(s)
headers={'F':('SYCL: flush FP16 FA TILE VKQ to FP32 per KV tile','F ported from the P100 project, patch 0004\n'),'S':('SYCL: cap FA TILE keys per block','')}
for v,files in [('F',[rel]),('S',[common,rel])]:
 subject,credit=headers[v]
 header=f'Subject: [PATCH] {subject}\n\nWhy: p11b CPU numerics at A770 geometry measured TILE NMSE about 8e-6\nat 1024 keys per accumulator and about 1.5e-4 at 2048; g-min fails\nat 4096, while g-a770 reaches 0.44 / 2.3 at 8192 / 16384 (tolerance 5e-4).\nTested on: Intel OpenCL CPU device only\n{credit}Applies independently on llama.cpp 79e2e74 + A770 patches 0001-0005.\nCandidate only; A770 A/B decision pending.\n\n'
 diff=''
 for file in files:
  a=(root/'third_party/p11c/base'/file).read_text();z=(root/'third_party/p11c'/v/file).read_text()
  diff+=f'diff --git a/{file} b/{file}\n'+''.join(difflib.unified_diff(a.splitlines(True),z.splitlines(True),fromfile='a/'+file,tofile='b/'+file))
 name= 'F-SYCL-FA-tile-flush-FP16-VKQ-to-FP32-per-KV-tile.patch' if v=='F' else 'S-SYCL-FA-tile-cap-keys-per-block.patch'
 (root/'third_party/patches/p11c'/name).write_text(header+diff)
 (out/f'{v}-candidate.diff').write_text(diff)
 for fresh in (root/'third_party/p11c/base',):
  subprocess.run(['git','-C',str(fresh),'apply','--check',str(root/'third_party/patches/p11c'/name)],check=True)
 print(v,'apply --check on base: PASS')
# archive the identical scratch-only diagnostics, after candidates exist
for v in ('base','F','S'):
 p=root/'third_party/p11c'/v
 patch=root/'bench/results/p11b-sycl-fa-fp16-geometry-20261011/A-scratch-diagnostics.diff'
 subprocess.run(['git','-C',str(p),'apply',str(patch)],check=True)
 (out/f'{v}-scratch-diagnostics.diff').write_bytes(patch.read_bytes())
