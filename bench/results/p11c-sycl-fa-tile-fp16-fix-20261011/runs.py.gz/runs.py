import os,pathlib,re,subprocess,time,json
root=pathlib.Path.cwd();out=root/'bench/results/p11c-sycl-fa-tile-fp16-fix-20261011'
p=re.search(r"^P='(.*)'$",(root/'bench/results/sycl-cpu-fa-baseline-20261010/README.txt').read_text(),re.M).group(1)
(out/'filters.txt').write_text('P='+p+'\nP6=nr23=\\[[3567],1\\]\nBIAS=v_bias=2\n')
env=os.environ.copy();env.update(A770_TOOLS='/home/p51/Github/A770/tools',SYCL_CACHE_PERSISTENT='1',SYCL_CACHE_DIR='/tmp/p11c-sycl-cache',GGML_SYCL_MKL_FA_DEBUG='1')
for k in ('SYCL_PROGRAM_COMPILE_OPTIONS','SYCL_PROGRAM_BUILD_OPTIONS','SYCL_CPU_F16'):env.pop(k,None)
commands=[]
def run(name,args,e):
 print('START',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  rc=subprocess.run(args,env=e,stdout=f,stderr=subprocess.STDOUT).returncode
 elapsed=time.monotonic()-start
 (out/(name+'.time')).write_text(f'wall_seconds={elapsed:.2f} actual_exit={rc}\n')
 commands.append(dict(name=name,args=args,geometry={k:e.get(k) for k in ('GGML_SYCL_TEST_NSM','GGML_SYCL_TEST_MAX_WG_PER_CU')},LLAMA=e.get('LLAMA'),wall_seconds=round(elapsed,2),actual_exit=rc))
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 lines=(out/(name+'.log')).read_text(errors='replace').splitlines()
 print('END',name,f'{elapsed:.2f}s exit={rc}',*[s for s in lines if 'tests passed' in s or 'backends passed' in s][-4:],sep='\n',flush=True)
 return rc
for v in ('base','F','S'):
 env['LLAMA']=str(root/'third_party/p11c'/v)
 for geometry,m in (('g-a770','2'),('g-min','1')):
  e=env.copy();e.update(GGML_SYCL_TEST_NSM='32',GGML_SYCL_TEST_MAX_WG_PER_CU=m)
  rc=run(f'{v}-{geometry}-bias',['bin/sycl-cpu-tbo.sh','-o','FLASH_ATTN_EXT','-p','v_bias=2'],e)
  if not (out/f'{v}-{geometry}-bias.log').read_text(errors='replace').count('16 tests') and rc not in (0,1):raise SystemExit('Build/runtime stop')
 if v=='base':continue
 for geometry,m in (('g-cpu',None),('g-a770','2')):
  e=env.copy()
  for k in ('GGML_SYCL_TEST_NSM','GGML_SYCL_TEST_MAX_WG_PER_CU'):e.pop(k,None)
  if m:e.update(GGML_SYCL_TEST_NSM='32',GGML_SYCL_TEST_MAX_WG_PER_CU=m)
  for subset,filt in (('P',p),('P6',r'nr23=\[[3567],1\]')):
   run(f'{v}-{geometry}-{subset}',['bin/sycl-cpu-tbo.sh','-o','FLASH_ATTN_EXT','-p',filt],e)
# Run new static reports for both variants; no old-report equivalence assumption.
for v in ('base','F'):
 e=env.copy();e['LLAMA']=str(root/'third_party/p11c'/v)
 for k in ('GGML_SYCL_TEST_NSM','GGML_SYCL_TEST_MAX_WG_PER_CU','GGML_SYCL_TEST_CPU'):e.pop(k,None)
 run('static-'+v,['bin/llama-sycl-fa-static.sh',str(out/('static-'+v))],e)
print('ALL RUNS FINISHED',flush=True)
